'use strict';
// LUMIA REALM - multiplayer, dependency-free Node.js server.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { randomUUID } = require('node:crypto');

const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0';
const WORLD = { width: 2800, height: 1800 };
const MAX_PLAYERS = 32;
const players = new Map();
const streams = new Map();
const monsters = new Map();
const effects = [];
const publicDir = path.join(__dirname, 'public');
const species = [
  { type: 'slime', name: '풀잎 슬라임', hp: 40, damage: 5, exp: 25, coins: 8, speed: 45 },
  { type: 'mushroom', name: '별송이', hp: 70, damage: 9, exp: 44, coins: 15, speed: 37 },
  { type: 'wisp', name: '달빛 정령', hp: 110, damage: 13, exp: 70, coins: 23, speed: 62 }
];
const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
const sqdist = (a, b) => (a.x-b.x)**2 + (a.y-b.y)**2;
const random = (lo, hi) => lo + Math.random() * (hi-lo);
const expNeeded = level => 50 + 25 * level + 5 * level * level;
const maxHp = level => 100 + (level - 1) * 17;
const now = () => Date.now();
let monsterCount = 0;
let nextId = 1;

function monsterSpawn(typeIndex) {
  const type = species[typeIndex];
  // Lower-level monsters are more common near the starting meadow.
  const region = typeIndex === 0
    ? { x1: 100, x2: 1560, y1: 110, y2: 1650 }
    : typeIndex === 1
      ? { x1: 910, x2: 2460, y1: 150, y2: 1690 }
      : { x1: 1630, x2: 2680, y1: 100, y2: 1680 };
  const m = {
    id: 'm' + nextId++, type: type.type,
    x: random(region.x1, region.x2), y: random(region.y1, region.y2),
    homeX: 0, homeY: 0, hp: type.hp, maxHp: type.hp,
    heading: random(-Math.PI, Math.PI), nextTurn: now() + random(1000, 3500),
    attackAt: 0, lastHit: 0, respawnAt: 0, kind: typeIndex,
  };
  m.homeX = m.x; m.homeY = m.y;
  monsters.set(m.id, m);
}
for (let i = 0; i < 18; i++) monsterSpawn(0);
for (let i = 0; i < 11; i++) monsterSpawn(1);
for (let i = 0; i < 8; i++) monsterSpawn(2);

function safeName(value) {
  const str = String(value || '').replace(/[<>\u0000-\u001f]/g, '').trim().slice(0, 16);
  return str || '모험가';
}
function makePlayer(name) {
  const token = randomUUID();
  const p = {
    token, id: 'p' + randomUUID().slice(0, 8), name: safeName(name),
    x: random(420, 600), y: random(580, 760),
    dx: 0, dy: 0, facingX: 1, facingY: 0,
    hp: 100, level: 1, xp: 0, coins: 0, kills: 0,
    attack: false, attackAt: 0, dashAt: 0, dashUntil: 0,
    emote: '', emoteUntil: 0, invulnUntil: 0,
    color: ['#5cbbfa','#ffc972','#da9bff','#78e8b0','#ff96a5','#9daaff'][Math.floor(random(0, 6))],
    lastSeen: now(), lastInput: 0,
  };
  players.set(token, p);
  return p;
}
function removePlayer(token) {
  players.delete(token);
  const res = streams.get(token);
  if (res) { try { res.end(); } catch {} streams.delete(token); }
}
function shortPlayer(p) {
  return {
    id: p.id, name: p.name, x: Math.round(p.x), y: Math.round(p.y),
    level: p.level, hp: p.hp, maxHp: maxHp(p.level),
    xp: p.xp, xpNext: expNeeded(p.level), coins: p.coins, kills: p.kills,
    color: p.color, facingX: p.facingX, facingY: p.facingY,
    attackAt: p.attackAt, dashUntil: p.dashUntil,
    emote: p.emoteUntil > now() ? p.emote : ''
  };
}
function shortMonster(m) {
  return { id: m.id, type: m.type, x: Math.round(m.x), y: Math.round(m.y),
    hp: m.hp, maxHp: m.maxHp, lastHit: m.lastHit };
}
function fx(type, x, y, text = '', color = '#ffffff') {
  effects.push({ id: randomUUID().slice(0, 8), type, x: Math.round(x), y: Math.round(y), text, color, time: now() });
  if (effects.length > 80) effects.splice(0, effects.length - 80);
}
function attackMonster(p, t) {
  const damage = 18 + Math.floor(p.level * 4.2) + Math.floor(random(0, 7));
  t.hp = Math.max(0, t.hp - damage);
  t.lastHit = now();
  fx('hit', t.x, t.y - 15, '-' + damage, '#fff0ad');
  if (t.hp === 0) {
    const type = species[t.kind];
    t.respawnAt = now() + 3500 + random(0, 3000);
    p.xp += type.exp;
    p.coins += type.coins;
    p.kills++;
    fx('loot', t.x, t.y - 18, '+' + type.exp + ' EXP', '#98ffe0');
    if (p.xp >= expNeeded(p.level)) {
      while (p.level < 50 && p.xp >= expNeeded(p.level)) {
        p.xp -= expNeeded(p.level);
        p.level++;
      }
      p.hp = maxHp(p.level);
      fx('level', p.x, p.y - 55, 'LEVEL UP!', '#ffe494');
    }
  }
}
function gameTick() {
  const t = now();
  const dt = 1 / 30;
  for (const [token, p] of players) {
    if (t - p.lastSeen > 35_000) { removePlayer(token); continue; }
    if (t - p.lastInput > 450) { p.dx = 0; p.dy = 0; p.attack = false; }
    let x = p.dx, y = p.dy;
    const len = Math.hypot(x, y);
    if (len > 1) { x /= len; y /= len; }
    if (len > .12) { const normalized = Math.hypot(x, y); p.facingX = x / normalized; p.facingY = y / normalized; }
    let speed = 205 + Math.min(p.level, 20) * 3;
    if (p.dashUntil > t) speed *= 2.6;
    p.x = clamp(p.x + x * speed * dt, 34, WORLD.width - 34);
    p.y = clamp(p.y + y * speed * dt, 48, WORLD.height - 42);
    if (p.attack && t >= p.attackAt) {
      p.attackAt = t + 420;
      let target = null;
      let targetDist = Infinity;
      for (const m of monsters.values()) {
        if (m.hp <= 0) continue;
        const d2 = sqdist(p, m);
        if (d2 > 117 * 117) continue;
        const dist = Math.sqrt(d2);
        const facing = ((m.x-p.x) * p.facingX + (m.y-p.y) * p.facingY) / Math.max(dist, 1);
        if (facing < -.12) continue;
        if (d2 < targetDist) { target = m; targetDist = d2; }
      }
      fx('swing', p.x + p.facingX * 48, p.y + p.facingY * 48, '', '#d1fff6');
      if (target) attackMonster(p, target);
    }
    // The village fountain restores health, making a clear safe destination.
    if ((p.x - 390) ** 2 + (p.y - 660) ** 2 < 90 ** 2 && p.hp < maxHp(p.level)) {
      p.hp = Math.min(maxHp(p.level), p.hp + 2 * dt);
    }
  }
  for (const m of monsters.values()) {
    if (m.hp <= 0) {
      if (t >= m.respawnAt) {
        m.hp = m.maxHp;
        m.x = m.homeX + random(-50, 50);
        m.y = m.homeY + random(-50, 50);
      }
      continue;
    }
    let nearest = null, best = 250 * 250;
    for (const p of players.values()) {
      const d2 = sqdist(p, m);
      if (d2 < best) { nearest = p; best = d2; }
    }
    const type = species[m.kind];
    if (nearest && best < 250 ** 2) {
      const d = Math.sqrt(best) || 1;
      if (d > 42) {
        const factor = m.kind === 2 ? 1.18 : 1;
        m.x += (nearest.x - m.x) / d * type.speed * factor * dt;
        m.y += (nearest.y - m.y) / d * type.speed * factor * dt;
      } else if (t > m.attackAt && t > nearest.invulnUntil) {
        nearest.hp = Math.max(0, Math.ceil(nearest.hp - type.damage));
        m.attackAt = t + 1250;
        nearest.invulnUntil = t + 650;
        fx('ouch', nearest.x, nearest.y - 36, '-' + type.damage, '#ffb7aa');
        if (nearest.hp <= 0) {
          nearest.x = 390; nearest.y = 750;
          nearest.hp = maxHp(nearest.level);
          nearest.invulnUntil = t + 3000;
          fx('return', nearest.x, nearest.y - 45, '마을로 귀환!', '#b4e5ff');
        }
      }
    } else {
      if (t > m.nextTurn) {
        m.heading = random(-Math.PI, Math.PI);
        m.nextTurn = t + random(1500, 4700);
      }
      const homeDist = Math.hypot(m.x-m.homeX, m.y-m.homeY);
      if (homeDist > 125) m.heading = Math.atan2(m.homeY - m.y, m.homeX - m.x);
      m.x += Math.cos(m.heading) * type.speed * .30 * dt;
      m.y += Math.sin(m.heading) * type.speed * .30 * dt;
    }
    m.x = clamp(m.x, 30, WORLD.width - 30);
    m.y = clamp(m.y, 30, WORLD.height - 30);
  }
  for (let i = effects.length - 1; i >= 0; i--) if (t - effects[i].time > 900) effects.splice(i, 1);
}

function snapshot() {
  const all = [...players.values()].map(shortPlayer);
  return JSON.stringify({
    now: now(), world: WORLD,
    players: all,
    monsters: [...monsters.values()].filter(m => m.hp > 0).map(shortMonster),
    effects,
    leaderboard: all.slice().sort((a, b) => b.level-a.level || b.kills-a.kills).slice(0, 6)
      .map(p => ({name: p.name, level: p.level, kills: p.kills})),
  });
}
function broadcast() {
  if (!streams.size) return;
  const message = 'event: world\ndata: ' + snapshot() + '\n\n';
  for (const [token, res] of streams) {
    if (!players.has(token) || res.destroyed || !res.writable) { streams.delete(token); continue; }
    try { res.write(message); } catch { streams.delete(token); }
  }
}
setInterval(gameTick, 1000 / 30).unref();
setInterval(broadcast, 100).unref();
setInterval(() => {
  for (const res of streams.values()) { try { res.write(': keepalive\n\n'); } catch {} }
}, 15_000).unref();

function sendJSON(res, status, obj) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}
function parseJSON(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 2000) { reject(new Error('too big')); req.destroy(); }
    });
    req.on('end', () => { try { resolve(JSON.parse(body || '{}')); } catch { reject(new Error('invalid JSON')); } });
    req.on('error', reject);
  });
}
const assets = {
  '/': ['index.html', 'text/html; charset=utf-8'],
  '/index.html': ['index.html', 'text/html; charset=utf-8'],
  '/styles.css': ['styles.css', 'text/css; charset=utf-8'],
  '/game.js': ['game.js', 'application/javascript; charset=utf-8'],
};
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (req.method === 'GET' && url.pathname === '/health') return sendJSON(res, 200, { ok: true, online: players.size, monsters: monsters.size });
  if (req.method === 'POST' && url.pathname === '/api/join') {
    let b;
    try { b = await parseJSON(req); } catch { return sendJSON(res, 400, { error: '잘못된 요청입니다.' }); }
    let p = typeof b.token === 'string' ? players.get(b.token) : null;
    if (!p && players.size >= MAX_PLAYERS) return sendJSON(res, 503, { error: '서버가 가득 찼어요. 잠시 후 다시 시도해 주세요.' });
    if (!p) p = makePlayer(b.name);
    p.lastSeen = now();
    return sendJSON(res, 200, { token: p.token, id: p.id, player: shortPlayer(p) });
  }
  if (req.method === 'POST' && url.pathname === '/api/input') {
    let b;
    try { b = await parseJSON(req); } catch { return sendJSON(res, 400, { error: '잘못된 요청입니다.' }); }
    const p = players.get(b.token);
    if (!p) return sendJSON(res, 401, { error: '세션이 종료되었습니다.' });
    const t = now();
    if (t - p.lastInput < 18) return sendJSON(res, 200, { ok: true });
    p.lastInput = p.lastSeen = t;
    p.dx = clamp(Number(b.dx) || 0, -1, 1);
    p.dy = clamp(Number(b.dy) || 0, -1, 1);
    p.attack = b.attack === true;
    if (b.dash === true && t > p.dashAt && (Math.abs(p.dx) + Math.abs(p.dy)) > .1) {
      p.dashAt = t + 2600;
      p.dashUntil = t + 240;
      fx('dash', p.x, p.y, '', '#b8f1ff');
    }
    const allowedEmotes = ['안녕!', '같이 가요!', '도와줘!', '최고!', '고마워!'];
    if (typeof b.emote === 'string' && allowedEmotes.includes(b.emote)) {
      p.emote = b.emote; p.emoteUntil = t + 2500;
    }
    return sendJSON(res, 200, { ok: true });
  }
  if (req.method === 'GET' && url.pathname === '/api/events') {
    const token = url.searchParams.get('token');
    const p = players.get(token);
    if (!p) return sendJSON(res, 401, { error: '세션이 종료되었습니다.' });
    p.lastSeen = now();
    const existing = streams.get(token);
    if (existing) { try { existing.end(); } catch {} }
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no',
    });
    res.write('retry: 1000\n\n');
    res.write('event: world\ndata: ' + snapshot() + '\n\n');
    streams.set(token, res);
    req.on('close', () => { if (streams.get(token) === res) streams.delete(token); });
    return;
  }
  if (req.method === 'GET' && assets[url.pathname]) {
    const [file, type] = assets[url.pathname];
    fs.readFile(path.join(publicDir, file), (err, bytes) => {
      if (err) return sendJSON(res, 500, { error: '파일을 불러올 수 없습니다.' });
      res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
      res.end(bytes);
    });
    return;
  }
  sendJSON(res, 404, { error: '페이지를 찾을 수 없습니다.' });
});
server.listen(PORT, HOST, () => console.log(`LUMIA REALM multiplayer online at http://localhost:${PORT}`));
module.exports = { server, players, monsters, snapshot };
