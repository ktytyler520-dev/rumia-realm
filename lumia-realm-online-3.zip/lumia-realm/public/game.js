(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const canvas = $('gameCanvas'), ctx = canvas.getContext('2d', { alpha: false });
  const mapCanvas = $('minimapCanvas'), mapCtx = mapCanvas.getContext('2d');
  const W = canvas.width, H = canvas.height, WORLD = { width: 2800, height: 1800 };
  const soloRequested = Boolean(window.LUMIA_DEMO_MODE) || location.protocol === 'file:' || new URLSearchParams(location.search).has('demo');
  let isDemo = soloRequested;
  let state = { now: Date.now(), players: [], monsters: [], effects: [], leaderboard: [] };
  let myId = '', token = '', connected = false, started = false, stream = null;
  let lastPacket = 0, clockOffset = 0, lastHud = 0, lastSend = 0, lastFrame = performance.now();
  let camera = { x: 0, y: 0 }, flashes = {}, smooth = {}, shownEffects = new Set();
  const keys = new Set(), stick = { x: 0, y: 0, pointer: null }, input = { x: 0, y: 0, attack: false, dash: false, emote: '' };
  let attackPointer = false, audioOn = false, audioCtx = null, toastTimer = 0;
  let activeDemo = null;
  const props = [], terrainSpots = [];

  // Deterministic decorative details for every visitor, without image downloads.
  const hash = (x, y, salt = 0) => {
    const n = Math.sin(x * 127.1 + y * 311.7 + salt * 19.19) * 43758.5453;
    return n - Math.floor(n);
  };
  const rand = (a, b, s) => hash(a, b, s);
  const clamp = (v, min, max) => Math.min(max, Math.max(min, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  function roundedRect(x, y, w, h, r, color) {
    ctx.fillStyle = color;
    ctx.beginPath(); ctx.roundRect(x, y, w, h, r); ctx.fill();
  }
  function ellipse(x, y, rx, ry, color) {
    ctx.fillStyle = color; ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2); ctx.fill();
  }
  function line(x1, y1, x2, y2, width, color) {
    ctx.strokeStyle = color; ctx.lineWidth = width; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  }
  function textAt(text, x, y, font, color, align = 'center') {
    ctx.textAlign = align; ctx.textBaseline = 'middle'; ctx.font = font; ctx.fillStyle = color; ctx.fillText(text, x, y);
  }
  for (let i = 0; i < 460; i++) {
    const x = 28 + rand(i, 4) * (WORLD.width - 56);
    const y = 25 + rand(i, 17) * (WORLD.height - 50);
    if (Math.hypot(x - 390, y - 660) < 210) continue;
    if (Math.hypot(x - 1750, y - 540) < 205) continue;
    const forest = x > 1120 || y < 300;
    const type = rand(i, 25) < (forest ? .35 : .12) ? 'tree' : rand(i, 11) < .16 ? 'stone' : rand(i, 12) < .22 ? 'mush' : 'flower';
    props.push({ x, y, type, size: rand(i, 33) * .6 + .7, tone: rand(i, 19) });
  }
  props.sort((a, b) => a.y - b.y);
  for (let i = 0; i < 270; i++) terrainSpots.push({ x: rand(i, 3) * WORLD.width, y: rand(i, 41) * WORLD.height, s: rand(i, 90) * 42 + 18 });

  function drawTerrain(t) {
    const bg = ctx.createLinearGradient(0, 0, WORLD.width, WORLD.height);
    bg.addColorStop(0, '#89c97a'); bg.addColorStop(.52, '#70b56f'); bg.addColorStop(1, '#4b9375');
    ctx.fillStyle = bg; ctx.fillRect(0, 0, WORLD.width, WORLD.height);
    for (const b of terrainSpots) {
      if (b.x < camera.x - 130 || b.x > camera.x + W + 130 || b.y < camera.y - 130 || b.y > camera.y + H + 130) continue;
      ellipse(b.x, b.y, b.s * 1.5, b.s * .65, b.x > 1500 ? '#4f9c7935' : '#c3da7b34');
    }
    // Forest shade at the far east of the world.
    const mist = ctx.createLinearGradient(1600, 0, 2800, 0);
    mist.addColorStop(0, '#50987700'); mist.addColorStop(1, '#356f7934');
    ctx.fillStyle = mist; ctx.fillRect(1600, 0, 1200, WORLD.height);
    // Trails are part of the level geography (not a scrolling background image).
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.beginPath(); ctx.moveTo(310, 715); ctx.bezierCurveTo(580, 750, 760, 510, 1210, 660); ctx.bezierCurveTo(1550, 790, 1730, 990, 2440, 1130);
    ctx.strokeStyle = '#5b9a633c'; ctx.lineWidth = 112; ctx.stroke();
    ctx.strokeStyle = '#d0be8b'; ctx.lineWidth = 83; ctx.stroke();
    ctx.strokeStyle = '#dfd0a3'; ctx.lineWidth = 67; ctx.stroke();
    ctx.strokeStyle = '#f3e1ad31'; ctx.lineWidth = 24; ctx.stroke();
    // Magical pond, rocky banks and water highlights.
    ellipse(1730, 505, 220, 164, '#7bb39e');
    ellipse(1730, 500, 196, 148, '#4f9bae');
    ellipse(1730, 495, 178, 131, '#65bad0');
    for (let k = 0; k < 8; k++) {
      const x = 1605 + k * 36, y = 490 + Math.sin(k * 1.7 + t / 2400) * 12;
      ellipse(x, y, 16, 3, '#caf8eb66');
    }
    ellipse(390, 668, 176, 155, '#99ba88');
    ellipse(390, 660, 156, 135, '#d5c69b');
    ellipse(390, 662, 130, 112, '#eadcb3');
    // cobbled village ring
    for (let i = 0; i < 24; i++) {
      const a = i / 24 * Math.PI * 2, r = 101;
      ellipse(390 + Math.cos(a) * r, 660 + Math.sin(a) * r * .82, 12, 5, '#fff0c352');
    }
    drawHouse(230, 532, '#dfb87d'); drawHouse(595, 610, '#cfa889');
    drawFountain(390, 660, t);
    drawSign(680, 575, '초원 →');
    drawSign(1490, 833, '달빛 숲 →');
    // Sparse grass patterns and pebbles.
    const col1 = Math.max(0, Math.floor((camera.x - 80) / 72));
    const col2 = Math.min(39, Math.floor((camera.x + W + 80) / 72));
    const row1 = Math.max(0, Math.floor((camera.y - 80) / 72));
    const row2 = Math.min(25, Math.floor((camera.y + H + 80) / 72));
    for (let gx = col1; gx <= col2; gx++) for (let gy = row1; gy <= row2; gy++) {
      const v = hash(gx, gy);
      const x = gx * 72 + v * 59, y = gy * 72 + hash(gx, gy, 3) * 57;
      if (Math.hypot(x-390, y-660) < 160) continue;
      if (v > .67) {
        line(x-5, y+5, x-1, y-4, 2, '#477c5380'); line(x+2, y+5, x+4, y-6, 2, '#427d5480');
      } else if (v < .12) ellipse(x, y, 2.7, 1.7, '#fff0d275');
    }
  }
  function drawHouse(x, y, color) {
    ellipse(x, y+13, 65, 24, '#376b5666');
    roundedRect(x-49, y-39, 98, 75, 9, '#f9eac3');
    roundedRect(x-42, y-32, 84, 64, 5, color);
    ctx.beginPath(); ctx.moveTo(x-61, y-36); ctx.lineTo(x, y-98); ctx.lineTo(x+61, y-36); ctx.closePath(); ctx.fillStyle='#a8615b'; ctx.fill();
    line(x-57,y-34,x+56,y-34,5,'#f5bc87');
    roundedRect(x-11,y,22,36,[7,7,0,0],'#694b49');
    ellipse(x+26,y-7,9,10,'#9de9cb');
  }
  function drawSign(x, y, label) {
    ellipse(x,y+7,22,7,'#4779617c');
    line(x,y,x,y-70,9,'#78553d');
    roundedRect(x-48,y-73,96,30,5,'#9f714c');
    roundedRect(x-44,y-70,88,24,4,'#d8b681');
    textAt(label,x,y-57,'bold 14px sans-serif','#554431');
  }
  function drawFountain(x, y, t) {
    ellipse(x,y+20,78,31,'#7f9e86');
    ellipse(x,y+10,71,27,'#e7e2cb');
    ellipse(x,y+8,63,20,'#55aab8');
    ellipse(x,y+10,55,16,'#7cdde1');
    roundedRect(x-17,y-20,34,31,9,'#e7e6d2');
    ellipse(x,y-18,26,11,'#f6edd5');
    ellipse(x,y-20,19,6,'#8ad8e1');
    line(x,y-25,x,y-52,5,'#b9f5e5');
    ellipse(x,y-57 + Math.sin(t/420)*3,8,12,'#e3ffebd4');
    textAt('✦',x,y-82,'bold 22px sans-serif','#f4fff3');
  }
  function drawProp(o, t) {
    const {x,y,type,size:s,tone} = o;
    if (type === 'tree') {
      ellipse(x,y+6,28*s,11*s,'#34694d52');
      roundedRect(x-8*s,y-37*s,16*s,49*s,4*s,'#785742');
      ellipse(x-11*s,y-39*s,32*s,33*s, tone>.45?'#378c68':'#3d9165');
      ellipse(x+14*s,y-50*s,30*s,29*s,tone>.45?'#4aa47b':'#51aa74');
      ellipse(x-2*s,y-68*s,30*s,34*s,tone>.45?'#5cb27d':'#66b683');
      ellipse(x-14*s,y-64*s,9*s,6*s,'#acda9c61');
    } else if (type === 'stone') {
      ellipse(x,y+3,14*s,6*s,'#39775a38');
      ellipse(x,y-2,12*s,9*s,tone>.5?'#a5b5a1':'#c0c8b0');
      ellipse(x-3*s,y-5*s,6*s,3*s,'#e3e4d16c');
    } else if (type === 'mush') {
      line(x,y,x,y-9*s,4*s,'#e9e2c2');
      ellipse(x,y-10*s,11*s,6*s,tone>.5?'#e4a4a2':'#9db0df');
      ellipse(x-3*s,y-12*s,2*s,2*s,'#fff0de');
      ellipse(x+5*s,y-10*s,2*s,2*s,'#fff0de');
    } else {
      const col = tone > .65 ? '#ffdb87' : tone > .32 ? '#e9c0e6' : '#e7f6bb';
      line(x,y+1,x,y-6*s,1.5,'#438c5d');
      ellipse(x-4*s,y-7*s,3*s,3*s,col);ellipse(x+4*s,y-7*s,3*s,3*s,col);
      ellipse(x,y-11*s,3*s,3*s,col);ellipse(x,y-5*s,3*s,3*s,col);
      ellipse(x,y-8*s,2*s,2*s,'#f4b970');
    }
  }
  function drawMonster(m, t) {
    const x=m.x, y=m.y, kind=m.type, wobble=Math.sin(t/260 + x)*2;
    ellipse(x,y+8,32,10,'#255a4b49');
    if (kind === 'slime') {
      ctx.fillStyle='#77dd9d';ctx.strokeStyle='#3f9d71';ctx.lineWidth=3;
      ctx.beginPath();ctx.moveTo(x-26,y);ctx.bezierCurveTo(x-35,y-24,x-19,y-47+wobble,x,y-46+wobble);
      ctx.bezierCurveTo(x+20,y-48+wobble,x+35,y-21,x+26,y);ctx.quadraticCurveTo(x,y+14,x-26,y);ctx.closePath();ctx.fill();ctx.stroke();
      ellipse(x-10,y-35+wobble,8,5,'#ffffff35');
      ellipse(x-10,y-19,4.5,6,'#194e40');ellipse(x+11,y-19,4.5,6,'#194e40');
      ellipse(x-8,y-21,1.5,2,'#fff');ellipse(x+13,y-21,1.5,2,'#fff');
      ctx.beginPath();ctx.arc(x,y-12,4,.1,Math.PI-.1);ctx.strokeStyle='#39775d';ctx.lineWidth=2;ctx.stroke();
    } else if(kind === 'mushroom') {
      ellipse(x,y-10+wobble,23,25,'#efdac8');
      ellipse(x-10,y-17,4,5,'#5a5364');ellipse(x+10,y-17,4,5,'#5a5364');
      roundedRect(x-31,y-47+wobble,62,22,12,'#ba86d4');
      ellipse(x,y-39+wobble,33,21,'#bb7dcb');
      ellipse(x-15,y-49+wobble,8,5,'#f4d6ee');ellipse(x+11,y-44+wobble,6,5,'#f4d6ee');
      ellipse(x-16,y-8,7,3,'#ffc1bc88');ellipse(x+15,y-8,7,3,'#ffc1bc88');
    } else {
      ctx.shadowBlur=22;ctx.shadowColor='#bdcaff';
      ellipse(x,y-26+wobble,26,31,'#a3aedf');ctx.shadowBlur=0;
      ctx.beginPath();ctx.moveTo(x-25,y-25);ctx.lineTo(x-24,y+2+wobble);ctx.lineTo(x-12,y-6);ctx.lineTo(x,y+3+wobble);ctx.lineTo(x+12,y-6);ctx.lineTo(x+24,y+2+wobble);ctx.lineTo(x+25,y-25);ctx.fillStyle='#a3aedf';ctx.fill();
      ellipse(x-9,y-30+wobble,4,6,'#474c8d');ellipse(x+9,y-30+wobble,4,6,'#474c8d');
      ellipse(x-10,y-44+wobble,10,5,'#e2e7ff55');
      textAt('✦',x+28,y-60+wobble,'bold 16px sans-serif','#ecf3ff');
    }
    const ratio=clamp(m.hp/m.maxHp,0,1);
    roundedRect(x-26,y-68,52,6,3,'#183f45ab');
    roundedRect(x-25,y-67,50*ratio,4,2,kind==='wisp'?'#dcacff':kind==='mushroom'?'#f7c3ed':'#b3f9c4');
  }
  function drawPlayer(p, t, isSelf) {
    const x=p.x, y=p.y;
    const moving=Number(p.moving||0), bounce=Math.sin(t/105 + x*.02)*2 * moving;
    const facingX=Number(p.facingX)||1, facingY=Number(p.facingY)||0;
    ellipse(x,y+8,24,9,'#20533c70');
    // Boots
    roundedRect(x-16,y-3+bounce,12,17,4,'#334759');
    roundedRect(x+4,y-3-bounce,12,17,4,'#334759');
    // Cape, body, and tiny belt
    ctx.beginPath();ctx.moveTo(x-18,y-43+bounce);ctx.lineTo(x+18,y-43+bounce);ctx.lineTo(x+22,y+4+bounce);ctx.quadraticCurveTo(x,y+13+bounce,x-22,y+4+bounce);ctx.closePath();
    ctx.fillStyle=p.color||'#79cfeb';ctx.fill();ctx.strokeStyle='#ffffff63';ctx.lineWidth=2;ctx.stroke();
    roundedRect(x-17,y-22+bounce,34,6,2,'#e0c388');
    roundedRect(x-6,y-22+bounce,12,7,2,'#f4dfaf');
    // Arms and gloves
    ellipse(x-21,y-25+bounce,8,11,'#f4d1b0');ellipse(x+21,y-25+bounce,8,11,'#f4d1b0');
    // Face
    ellipse(x,y-49+bounce,21,22,'#f8d9b5');
    // Hair cap and tuft
    ctx.beginPath();ctx.arc(x,y-51+bounce,21,Math.PI*1.05,Math.PI*2.05);ctx.lineTo(x+19,y-57+bounce);ctx.quadraticCurveTo(x+8,y-67+bounce,x-6,y-60+bounce);ctx.lineTo(x-20,y-56+bounce);ctx.fillStyle='#3b4e69';ctx.fill();
    ellipse(x-7,y-48+bounce,2.4,3.3,'#34485b');ellipse(x+8,y-48+bounce,2.4,3.3,'#34485b');
    ellipse(x-6,y-50+bounce,.9,1,'#ffffff');ellipse(x+9,y-50+bounce,.9,1,'#ffffff');
    ctx.beginPath();ctx.arc(x+1,y-42+bounce,3,.1,Math.PI-.1);ctx.lineWidth=1.5;ctx.strokeStyle='#bf8b7d';ctx.stroke();
    // A small magical orb lights up as spells are cast.
    const hitting=(t-(p.attackAt||0)+420)<230 && (t-(p.attackAt||0)+420)>-100;
    const handX=x+27, handY=y-24+bounce;
    ctx.save();
    ctx.shadowBlur=hitting?24:10;ctx.shadowColor='#d3fff3';
    ellipse(handX,handY-6,hitting?15:9,hitting?15:9,'#bafbef');
    ctx.restore();
    ellipse(handX-3,handY-9,3,3,'#fff');
    textAt('✧',handX+10,handY-19,'bold 13px sans-serif','#f9ffe3');
    if(hitting) {ctx.save();ctx.globalAlpha=.22;ctx.strokeStyle='#d9fff1';ctx.lineWidth=7;ctx.beginPath();ctx.arc(x+facingX*28,y-27+facingY*28,47,-1.5,1.5);ctx.stroke();ctx.restore();}
    if(isSelf) {
      ctx.strokeStyle='#fff5bf';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(x,y+8,31,12,0,0,Math.PI*2);ctx.stroke();
      textAt('▼',x,y-95,'bold 17px sans-serif','#fff2ac');
    }
    const label=p.name||'모험가';
    const pillW=Math.max(69,Math.min(155,label.length*12+45));
    roundedRect(x-pillW/2,y-85,pillW,21,10,isSelf?'#164b4bcc':'#133646b5');
    textAt('Lv.'+p.level+' '+label,x,y-74,'bold 11px sans-serif',isSelf?'#fff2b2':'#f7fff2');
    if(p.emote) {
      const eW=Math.max(76,p.emote.length*14+22);
      roundedRect(x-eW/2,y-133,eW,31,12,'#fffee9');
      textAt(p.emote,x,y-118,'bold 14px sans-serif','#27565c');
      ctx.fillStyle='#fffee9';ctx.beginPath();ctx.moveTo(x-7,y-103);ctx.lineTo(x+7,y-103);ctx.lineTo(x,y-96);ctx.fill();
    }
  }
  function drawFX(e, t) {
    const age=t-(e.time + clockOffset), alpha=clamp(1-age/880,0,1);
    if(alpha<=0) return;
    ctx.save(); ctx.globalAlpha=alpha;
    if(e.type==='swing'){
      ctx.strokeStyle='#f0fff1';ctx.lineWidth=7;ctx.shadowBlur=15;ctx.shadowColor='#cafffd';
      ctx.beginPath();ctx.arc(e.x,e.y,27,.2,Math.PI*1.28);ctx.stroke();
    } else if (e.type==='level' || e.type==='return') {
      ellipse(e.x,e.y,60+age*.12,15+age*.08,e.type==='level'?'#ffeda548':'#d1f1ff52');
      textAt(e.text,e.x,e.y-30-age*.07,'900 21px sans-serif',e.color);
    } else if(e.type==='dash'){
      ellipse(e.x,e.y,27+age*.13,12+age*.06,'#d6f5ffa0');
    } else {
      ctx.shadowBlur=3;ctx.shadowColor='#375554';
      textAt(e.text,e.x,e.y-35-age*.08,'900 18px sans-serif',e.color||'#fff');
    }
    ctx.restore();
  }
  function drawWorld(t) {
    const p=state.players.find(p=>p.id===myId) || state.players[0] || {x:450,y:650};
    const pp=smooth[p.id] || p;
    camera.x=lerp(camera.x,clamp(pp.x-W/2,0,WORLD.width-W),.08);
    camera.y=lerp(camera.y,clamp(pp.y-H/2,0,WORLD.height-H),.08);
    ctx.save(); ctx.translate(-camera.x,-camera.y);
    drawTerrain(t);
    // Merge decorative sprites and characters by Y-coordinate for layering.
    const items=[];
    for(const o of props){if(o.x>camera.x-110&&o.x<camera.x+W+110&&o.y>camera.y-130&&o.y<camera.y+H+130)items.push({y:o.y,kind:'prop',obj:o});}
    for(const m of state.monsters){const sm=smooth[m.id]||m;if(sm.x>camera.x-100&&sm.x<camera.x+W+100&&sm.y>camera.y-100&&sm.y<camera.y+H+100)items.push({y:sm.y,kind:'monster',obj:{...m,x:sm.x,y:sm.y}});}
    for(const q of state.players){const sp=smooth[q.id]||q;items.push({y:sp.y,kind:'player',obj:{...q,x:sp.x,y:sp.y,moving:sp.moving||0}});}
    items.sort((a,b)=>a.y-b.y);
    for(const it of items){if(it.kind==='prop')drawProp(it.obj,t);else if(it.kind==='monster')drawMonster(it.obj,t);else drawPlayer(it.obj,t,it.obj.id===myId);}
    for(const e of state.effects)drawFX(e,t);
    ctx.restore();
  }
  function drawMinimap() {
    const c=mapCtx, w=mapCanvas.width, h=mapCanvas.height;
    c.clearRect(0,0,w,h);c.fillStyle='#6ab27d';c.fillRect(0,0,w,h);
    for(let i=0;i<80;i++){
      c.fillStyle=i%3===0?'#478a714f':'#b3d79342';c.beginPath();c.arc(hash(i,7)*w,hash(i,13)*h,hash(i,11)*9+2,0,Math.PI*2);c.fill();
    }
    c.fillStyle='#73c4d7';c.beginPath();c.ellipse(1730/2800*w,500/1800*h,195/2800*w,142/1800*h,0,0,Math.PI*2);c.fill();
    c.fillStyle='#e3d6aa';c.beginPath();c.ellipse(390/2800*w,660/1800*h,105/2800*w,90/1800*h,0,0,Math.PI*2);c.fill();
    for(const m of state.monsters){c.fillStyle='#eeb3dc';c.fillRect(m.x/2800*w-1,m.y/1800*h-1,3,3);}
    for(const p of state.players){c.beginPath();c.arc(p.x/2800*w,p.y/1800*h,p.id===myId?4:3,0,Math.PI*2);c.fillStyle=p.id===myId?'#fff0a8':'#a4ddff';c.fill();}
    c.strokeStyle='#fff9c07a';c.lineWidth=1;c.strokeRect(camera.x/2800*w,camera.y/1800*h,Math.min(w,W/2800*w),Math.min(h,H/1800*h));
  }
  function syncSmooth(dt) {
    const ids=new Set();
    for(const obj of [...state.players,...state.monsters]){
      ids.add(obj.id);
      if(!smooth[obj.id])smooth[obj.id]={x:obj.x,y:obj.y,moving:0};
      const s=smooth[obj.id], delta=Math.hypot(obj.x-s.x,obj.y-s.y);
      if(delta>360){s.x=obj.x;s.y=obj.y;}
      else {const amount=1-Math.pow(.73,dt/16.7);s.x=lerp(s.x,obj.x,amount);s.y=lerp(s.y,obj.y,amount);}
      s.moving=clamp(delta/13,0,1);
    }
    for(const id of Object.keys(smooth))if(!ids.has(id))delete smooth[id];
  }
  function myPlayer(){return state.players.find(p=>p.id===myId);}
  function zoneFor(p){if(!p)return '새싹 초원';if(p.x>1750)return '달빛 숲';if(p.x>950)return '별송이 숲';if(Math.hypot(p.x-390,p.y-660)<190)return '햇살 마을';return '새싹 초원';}
  function levelTitle(level){return level>=20?'전설의 수호자':level>=10?'빛의 기사':level>=5?'숙련 모험가':'초보 모험가';}
  function updateUI() {
    const me=myPlayer();if(!me)return;
    $('hudName').textContent=me.name;$('hudLevel').textContent='LV.'+me.level;
    $('hudHpFill').style.width=(clamp(me.hp/me.maxHp,0,1)*100)+'%';$('hudHpText').textContent=Math.ceil(me.hp)+' / '+me.maxHp+' HP';
    $('hudExpFill').style.width=(clamp(me.xp/me.xpNext,0,1)*100)+'%';$('hudExpText').textContent=me.xp+' / '+me.xpNext+' EXP';
    $('zoneName').textContent=zoneFor(me);
    $('sideName').textContent=me.name;$('sideTitle').textContent=levelTitle(me.level);$('sideLv').innerHTML=String(me.level).padStart(2,'0')+'<span>LV</span>';
    $('sideXpText').textContent=me.xp+' / '+me.xpNext+' XP';$('sideXpFill').style.width=(me.xp/me.xpNext*100)+'%';
    $('sideCoins').textContent=me.coins.toLocaleString('ko-KR');$('sideKills').textContent=me.kills;
    $('questProgress').textContent=Math.min(5,me.kills)+' / 5';$('questFill').style.width=(Math.min(5,me.kills)/5*100)+'%';
    if(me.kills>=5){$('questCheck').textContent='✓';$('questCheck').style.color='#ffe5a0';}
    $('onlineText').textContent=isDemo?'혼자 체험 중':state.players.length+'명 접속 중';
    $('connectionDot').classList.toggle('connected',connected);
    const entries=state.leaderboard || [];
    $('rankingList').innerHTML='';
    if(!entries.length){$('rankingList').textContent='접속하면 순위가 표시돼요.';}
    entries.forEach((p,i)=>{
      const el=document.createElement('div');el.className='ranking-entry';
      const n=document.createElement('span');n.className='ranking-num';n.textContent=['♛','2','3','4','5','6'][i]||i+1;
      const name=document.createElement('span');name.className='ranking-name';name.textContent=p.name;
      const level=document.createElement('span');level.className='ranking-level';level.textContent='Lv.'+p.level;
      el.append(n,name,level);$('rankingList').appendChild(el);
    });
    drawMinimap();
  }
  function toast(msg){const el=$('toast');el.textContent=msg;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),1900);}
  function sound(freq=540,length=.13,kind='sine'){
    if(!audioOn)return;
    try{audioCtx ||= new (window.AudioContext||window.webkitAudioContext)();const osc=audioCtx.createOscillator(),gain=audioCtx.createGain();osc.type=kind;osc.frequency.setValueAtTime(freq,audioCtx.currentTime);osc.frequency.exponentialRampToValueAtTime(freq*.8,audioCtx.currentTime+length);gain.gain.setValueAtTime(.045,audioCtx.currentTime);gain.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+length);osc.connect(gain);gain.connect(audioCtx.destination);osc.start();osc.stop(audioCtx.currentTime+length);}catch{}
  }
  function onNewPacket(s){
    if(!s||!Array.isArray(s.players)||!Array.isArray(s.monsters))return;
    const oldMe=myPlayer();const oldLevel=oldMe?.level||1;
    state=s;clockOffset=Date.now()-s.now;lastPacket=Date.now();
    const me=myPlayer();if(me&&me.level>oldLevel){toast('✦ 레벨 '+me.level+' 달성!');sound(830,.25,'triangle');}
    if(me&&me.kills>(oldMe?.kills||0))sound(570,.09,'triangle');
  }
  const heroDemo = {id:'hero-demo',name:'모험가',x:450,y:720,level:1,hp:100,maxHp:100,xp:0,xpNext:80,coins:0,kills:0,color:'#7cdcef',facingX:1,facingY:0,attackAt:0,dashUntil:0,emote:''};
  function makeDemoMonsters(){
    const result=[];
    for(let i=0;i<28;i++){
      const x=620+hash(i,39)*1780,y=130+hash(i,71)*1540;
      const type=x>1680?'wisp':x>1110?'mushroom':'slime';
      const hp=type==='wisp'?110:type==='mushroom'?70:40;
      result.push({id:'d'+i,x,y,homeX:x,homeY:y,type,hp,maxHp:hp,attackAt:0,respawnAt:0,heading:hash(i,44)*6.28,lastTurn:0});
    }
    return result;
  }
  function startDemo(name){
    isDemo=true;connected=true;started=true;
    const me={...heroDemo,name};myId=me.id;
    activeDemo={me,monsters:makeDemoMonsters(),effects:[],lastAttack:0,lastDash:0,lastTick:performance.now()};
    state={now:Date.now(),players:[me],monsters:activeDemo.monsters,effects:[],leaderboard:[{name,level:1,kills:0}]};
    $('welcomeBackdrop').classList.add('hidden');$('underHint').textContent='체험 모드 · 온라인 연결은 서버 배포 후 가능';
    $('welcomeNote').textContent='체험 모드 실행 중';
    toast('✦ 모험을 시작합니다!');
  }
  function xpNeeded(level){return 50+25*level+5*level*level;}
  function demoTick(dt,t){
    const d=activeDemo;if(!d)return;
    const p=d.me,now=Date.now();
    const speed=(205+Math.min(p.level,20)*3)*(p.dashUntil>now?2.6:1);
    let vx=input.x,vy=input.y;
    if(Math.hypot(vx,vy)>1){const n=Math.hypot(vx,vy);vx/=n;vy/=n;}
    if(Math.hypot(vx,vy)>.12){p.facingX=vx/Math.hypot(vx,vy);p.facingY=vy/Math.hypot(vx,vy);}
    p.x=clamp(p.x+vx*speed*dt,34,WORLD.width-34);p.y=clamp(p.y+vy*speed*dt,48,WORLD.height-42);
    if(input.dash&&now>d.lastDash){p.dashUntil=now+240;d.lastDash=now+2600;input.dash=false;d.effects.push({id:'dash'+now,type:'dash',x:p.x,y:p.y,time:now,color:'#bbffff'});}
    if(input.emote){p.emote=input.emote;p.emoteUntil=now+2300;input.emote='';}
    if(p.emoteUntil<now)p.emote='';
    if(input.attack&&now>d.lastAttack){
      d.lastAttack=now+420;p.attackAt=now+420;
      d.effects.push({id:'swing'+now,type:'swing',x:p.x+p.facingX*48,y:p.y+p.facingY*48,time:now});
      let target=null,dist=Infinity;
      for(const m of d.monsters){if(m.hp<=0)continue;const dd=Math.hypot(m.x-p.x,m.y-p.y);if(dd>117)continue;const facing=((m.x-p.x)*p.facingX+(m.y-p.y)*p.facingY)/Math.max(dd,1);if(facing<-.12)continue;if(dd<dist){dist=dd;target=m;}}
      if(target){const harm=18+Math.floor(p.level*4.2)+Math.floor(Math.random()*7);target.hp=Math.max(0,target.hp-harm);d.effects.push({id:'hit'+now,type:'hit',x:target.x,y:target.y-15,text:'-'+harm,color:'#fff0ad',time:now});
        sound(360,.09,'triangle');
        if(target.hp===0){const exp=target.type==='wisp'?70:target.type==='mushroom'?44:25;const coins=target.type==='wisp'?23:target.type==='mushroom'?15:8;
          p.xp+=exp;p.coins+=coins;p.kills++;target.respawnAt=now+3800;
          d.effects.push({id:'loot'+now,type:'loot',x:target.x,y:target.y-15,text:'+'+exp+' EXP',color:'#a0ffe0',time:now});
          while(p.level<50&&p.xp>=xpNeeded(p.level)){p.xp-=xpNeeded(p.level);p.level++;p.maxHp=100+(p.level-1)*17;p.hp=p.maxHp;d.effects.push({id:'lv'+now,type:'level',x:p.x,y:p.y-45,text:'LEVEL UP!',color:'#fff09e',time:now});toast('✦ 레벨 '+p.level+' 달성!');sound(820,.25,'triangle');}
          p.xpNext=xpNeeded(p.level);
        }
      }
    }
    for(const m of d.monsters){
      if(m.hp===0){if(now>m.respawnAt){m.hp=m.maxHp;m.x=m.homeX;m.y=m.homeY;}continue;}
      const dd=Math.hypot(m.x-p.x,m.y-p.y),spd=m.type==='wisp'?60:m.type==='mushroom'?36:44;
      if(dd<220){if(dd>44){m.x+=(p.x-m.x)/dd*spd*dt;m.y+=(p.y-m.y)/dd*spd*dt;}
        else if(now>m.attackAt){m.attackAt=now+1250;p.hp=Math.max(0,p.hp-(m.type==='wisp'?13:m.type==='mushroom'?9:5));d.effects.push({id:'ouch'+now+m.id,type:'ouch',x:p.x,y:p.y-30,text:'-'+(m.type==='wisp'?13:m.type==='mushroom'?9:5),time:now,color:'#ffb6b1'});if(p.hp===0){p.x=390;p.y=750;p.hp=p.maxHp;toast('마을에서 다시 시작합니다!');}}
      }else{if(now>m.lastTurn){m.heading=Math.random()*6.28;m.lastTurn=now+1500+Math.random()*2500;}if(Math.hypot(m.x-m.homeX,m.y-m.homeY)>120)m.heading=Math.atan2(m.homeY-m.y,m.homeX-m.x);m.x+=Math.cos(m.heading)*spd*.35*dt;m.y+=Math.sin(m.heading)*spd*.35*dt;}
    }
    if(Math.hypot(p.x-390,p.y-660)<90)p.hp=Math.min(p.maxHp,p.hp+dt*2);
    d.effects=d.effects.filter(e=>now-e.time<900);
    state={now,players:[p],monsters:d.monsters.filter(m=>m.hp>0),effects:d.effects,leaderboard:[{name:p.name,level:p.level,kills:p.kills}]};
    clockOffset=0;
  }
  function moveVector(){
    const x=(keys.has('d')||keys.has('arrowright')?1:0)-(keys.has('a')||keys.has('arrowleft')?1:0);
    const y=(keys.has('s')||keys.has('arrowdown')?1:0)-(keys.has('w')||keys.has('arrowup')?1:0);
    if(Math.hypot(x,y)){
      const n=Math.hypot(x,y);return{x:x/n,y:y/n};
    }
    return{x:stick.x,y:stick.y};
  }
  function takeInput(){const m=moveVector();input.x=m.x;input.y=m.y;input.attack=keys.has(' ')||attackPointer;}
  function sendControls(t){
    if(!started||isDemo||!token||t-lastSend<66)return;
    lastSend=t;
    const data={token,dx:input.x,dy:input.y,attack:input.attack,dash:input.dash,emote:input.emote};
    input.dash=false;input.emote='';
    fetch('/api/input',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data),keepalive:false}).then(r=>{
      if(r.status===401){connected=false;stream?.close();$('welcomeBackdrop').classList.remove('hidden');$('welcomeNote').textContent='연결이 끊어졌어요. 다시 입장해 주세요.';started=false;}
    }).catch(()=>{connected=false;});
  }
  function frame(t){
    const dt=clamp((t-lastFrame)||16,0,60);lastFrame=t;
    takeInput();
    if(isDemo&&activeDemo)demoTick(dt/1000,t);
    sendControls(t);
    syncSmooth(dt);drawWorld(t);
    if(t-lastHud>180){lastHud=t;updateUI();}
    const me=myPlayer();if(me&&!isDemo){const cd=(me.dashUntil||0)-Date.now();}
    $('dashCool').style.transform='scaleY('+(started && !isDemo && myPlayer()?.dashUntil>Date.now()?'.4':'0')+')';
    requestAnimationFrame(frame);
  }
  function updateStick(event){
    const e=$('joystick'),r=e.getBoundingClientRect();
    const cx=r.left+r.width/2,cy=r.top+r.height/2;
    const x=event.clientX-cx,y=event.clientY-cy,max=r.width*.30;
    const n=Math.hypot(x,y),z=n>max?max/n:1;
    const px=x*z,py=y*z;
    stick.x=px/max;stick.y=py/max;
    $('joystickKnob').style.transform=`translate(${px}px,${py}px)`;
  }
  const joystick=$('joystick');
  joystick.addEventListener('pointerdown',e=>{e.preventDefault();stick.pointer=e.pointerId;joystick.setPointerCapture(e.pointerId);updateStick(e);});
  joystick.addEventListener('pointermove',e=>{if(stick.pointer!==e.pointerId)return;e.preventDefault();updateStick(e);});
  function resetStick(e){if(e&&stick.pointer!==e.pointerId)return;stick.pointer=null;stick.x=0;stick.y=0;$('joystickKnob').style.transform='translate(0,0)';}
  joystick.addEventListener('pointerup',resetStick);joystick.addEventListener('pointercancel',resetStick);
  const atk=$('attackBtn'),dash=$('dashBtn');
  atk.addEventListener('pointerdown',e=>{e.preventDefault();atk.setPointerCapture(e.pointerId);attackPointer=true;atk.classList.add('pressed');});
  function stopAttack(){attackPointer=false;atk.classList.remove('pressed');}
  atk.addEventListener('pointerup',stopAttack);atk.addEventListener('pointercancel',stopAttack);
  dash.addEventListener('pointerdown',e=>{e.preventDefault();input.dash=true;sound(420,.07);dash.classList.add('pressed');setTimeout(()=>dash.classList.remove('pressed'),130);});
  const movable=new Set(['w','a','s','d','arrowup','arrowdown','arrowleft','arrowright',' ','shift']);
  window.addEventListener('keydown',e=>{
    if(document.activeElement?.tagName==='INPUT')return;
    const key=e.key.toLowerCase();if(movable.has(key))e.preventDefault();
    keys.add(key);if(key==='shift'&&!e.repeat)input.dash=true;
    if(key==='1'&&!e.repeat)input.emote='안녕!';if(key==='2'&&!e.repeat)input.emote='같이 가요!';
  });
  window.addEventListener('keyup',e=>keys.delete(e.key.toLowerCase()));
  window.addEventListener('blur',()=>{keys.clear();stopAttack();resetStick();});
  document.querySelectorAll('[data-emote]').forEach(b=>b.addEventListener('click',()=>{if(!started)return toast('모험을 시작해 주세요!');input.emote=b.dataset.emote;toast('💬 '+input.emote);}));
  $('soundToggle').addEventListener('click',()=>{audioOn=!audioOn;$('soundToggle').querySelector('span').textContent=audioOn?'사운드 ON':'사운드 OFF';if(audioOn)sound(600,.12);});
  $('shareBtn').addEventListener('click',async()=>{
    if(isDemo)return toast('체험 모드예요. 온라인 배포 후 링크를 공유할 수 있어요!');
    const link=location.origin+location.pathname;
    try{await navigator.clipboard.writeText(link);toast('✓ 게임 주소가 복사됐어요!');}
    catch{toast('주소창의 링크를 친구에게 보내 주세요!');}
  });
  $('demoButton').addEventListener('click',()=>startDemo($('nickname').value.trim()||'모험가'));
  const safeLocal={get(key){try{return localStorage.getItem(key);}catch{return null;}},set(key,value){try{localStorage.setItem(key,value);}catch{}}};
  const safeSession={get(key){try{return sessionStorage.getItem(key);}catch{return null;}},set(key,value){try{sessionStorage.setItem(key,value);}catch{}}};
  $('nickname').value=safeLocal.get('lumia-name')||'';
  if(soloRequested){$('welcomeNote').textContent='오프라인 체험 모드 · 인터넷 연결 불필요';$('startBtn').textContent='✦ 체험 시작하기 →';}
  $('joinForm').addEventListener('submit',async e=>{
    e.preventDefault();if(started)return;
    const name=($('nickname').value||'').trim().slice(0,12)||'모험가';
    safeLocal.set('lumia-name',name);
    if(isDemo)return startDemo(name);
    $('startBtn').disabled=true;$('startBtn').textContent='세계에 접속하는 중...';
    try{
      const res=await fetch('/api/join',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,token:safeSession.get('lumia-token')})});
      const data=await res.json();if(!res.ok)throw new Error(data.error||'접속 실패');
      token=data.token;myId=data.id;safeSession.set('lumia-token',token);
      state.players=[data.player];connected=true;started=true;
      $('welcomeBackdrop').classList.add('hidden');
      stream?.close();stream=new EventSource('/api/events?token='+encodeURIComponent(token));
      stream.addEventListener('world',event=>{try{onNewPacket(JSON.parse(event.data));connected=true;}catch(err){console.error(err);}});
      stream.addEventListener('error',()=>{connected=false;$('onlineText').textContent='재연결 중...';$('connectionDot').classList.remove('connected');});
      toast('✦ '+name+'님, 환영합니다!');
    }catch(err){$('welcomeNote').textContent='서버 연결 실패: '+err.message;$('demoButton').hidden=false;}
    finally{$('startBtn').disabled=false;$('startBtn').innerHTML='✦ 모험 시작하기 <span>→</span>';}
  });
  // Render the world immediately, even before the nickname is submitted.
  state.players=[heroDemo];state.monsters=makeDemoMonsters();myId=heroDemo.id;
  requestAnimationFrame(frame);
})();
