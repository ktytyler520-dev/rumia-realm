'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { spawn } = require('node:child_process');
const PORT = 3196;
let child;
const endpoint = `http://127.0.0.1:${PORT}`;

test('multiplayer server: connect players, send actions, broadcast state', async t => {
  child = spawn(process.execPath, ['server.js'], {
    cwd: require('node:path').join(__dirname, '..'),
    env: { ...process.env, PORT: String(PORT) },
    stdio: 'ignore'
  });
  t.after(() => child?.kill());
  for(let i=0;i<40;i++) {
    try { const res=await fetch(endpoint+'/health'); if(res.ok)break; } catch{}
    await new Promise(resolve=>setTimeout(resolve,50));
  }
  const health=await (await fetch(endpoint+'/health')).json();
  assert.equal(health.ok,true);assert.ok(health.monsters>=20);
  const join = async name => {
    const res=await fetch(endpoint+'/api/join',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name})});
    assert.equal(res.status,200);return res.json();
  };
  const a=await join('테스터');const b=await join('친구');
  assert.notEqual(a.id,b.id);
  const response=await fetch(endpoint+'/api/input',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:a.token,dx:1,dy:0,attack:true})});
  assert.equal(response.status,200);
  const bad=await fetch(endpoint+'/api/input',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:'wrong',dx:1})});
  assert.equal(bad.status,401);
  const sse=await fetch(endpoint+'/api/events?token='+encodeURIComponent(a.token));
  assert.equal(sse.status,200);
  assert.match(sse.headers.get('content-type'),/text\/event-stream/);
  const reader=sse.body.getReader();
  const {value}=await reader.read();
  const text=new TextDecoder().decode(value);
  assert.match(text,/event: world/);
  assert.match(text,/친구/);
  await reader.cancel();
  const page=await fetch(endpoint+'/');
  assert.equal(page.status,200);assert.match(await page.text(),/루미아 원정대/);
});
